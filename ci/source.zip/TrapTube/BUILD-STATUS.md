# TrapTube build status and limitations

## Checks performed in the current environment

- The uploaded ZIP was extracted successfully.
- The Xcode project file and `Info.plist` pass `plutil -lint`.
- All 18 `.swift` files pass Swift parser syntax checks (`swiftc -frontend -parse`).
- The app icon asset is a 1024 x 1024 RGB PNG and the asset-catalog JSON is valid.
- The project declares iOS 17.0 as its deployment target and includes the app, view, service, and asset files in its target.

## Checks that could not be performed here

This session runs on Linux and does not have Xcode, `xcodebuild`, `xcrun`, the Apple iOS SDK, an iOS Simulator, a macOS host, or an Apple code-signing identity. Parser checks do not type-check SwiftUI/AVFoundation/WebKit APIs and are not a substitute for an Xcode build. Therefore **no compiled `.app`, `.xcarchive`, or `.ipa` has been produced or verified in this environment**.

## Build on a Mac

Run:

```bash
./scripts/build-unsigned-ipa.sh
```

The script uses Xcode to build for a generic iOS device, then packages the resulting app as `dist/TrapTube-unsigned.ipa`. It deliberately disables code signing. This output is intended for a sideload workflow in which AltStore/AltServer signs the IPA with the user's Apple account. It is not App Store-ready and is not signed for direct installation.

## Build remotely on GitHub Actions

1. Push the contents of this project to a GitHub repository. Keep `.github/workflows/build-ios-unsigned-ipa.yml` and `scripts/build-unsigned-ipa.sh` in the repository root.
2. Run **Actions → Build TrapTube iOS IPA → Run workflow**, or push to `main` / `master`.
3. Download the `TrapTube-iOS-build` artifact from the completed workflow run. On success it contains `TrapTube-unsigned.ipa` and a SHA-256 checksum.
4. Import the unsigned IPA into AltStore/AltServer and let it sign the app for the target device. Follow AltStore's current device and Apple-account requirements.

The GitHub Actions job is a build route, not evidence of a successful build until it has actually run. If it fails, review `xcodebuild.log` in the workflow artifact (when present) and fix the reported compile error before trying again.

## Feature limitations in this source tree

- YouTube playback uses an embedded official YouTube player URL in a WebKit view. It does not extract a raw audio stream, download media, run in the background, or feed YouTube audio into the local DSP chain.
- Stem Studio is only a model availability boundary. No licensed Demucs/Core ML model is included and no model inference adapter exists, so actual stem separation is not implemented and remains disabled.
