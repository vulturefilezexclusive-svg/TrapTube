# TrapTube — native SwiftUI audio player

This is the **TrapTube-SwiftUI** project supplied in the conversation, updated with the supplied house artwork as its iOS app icon and source-level YouTube / Stem Studio additions. It is not the separate BANDOTUBE project in Vibecode; that cloud project’s source files were not included in the uploaded ZIP and could not be exported through the connected workspace while it was gated.

## Included features

- Native SwiftUI app targeting **iOS 17.0+** (Swift language mode 5).
- Local audio import from Files and persistent on-device library metadata.
- AVFoundation playback, queue/player controls and background audio for local media.
- 16-band equalizer, bass boost, master gain and dynamics stage.
- Local playlists, genre tags, theme color settings and a TypeType health-check connection boundary.
- **YouTube tab:** paste a standard YouTube video or playlist URL and play it through YouTube’s official embedded `youtube-nocookie.com` player inside `WKWebView`. It does not extract streams, download media, strip ads, play in the background, or feed YouTube audio into the app’s DSP chain. Search via YouTube Data API is not wired; it would require a properly configured API key and API client.
- **Stem Studio tab:** local track selection and a Core ML model availability boundary. The source ZIP does not contain an `htdemucs` Core ML model, and no inference adapter has been implemented. Consequently, the processing button is disabled and the app does not create fake stems. A real implementation still needs a licensed/verified model asset, model input/output mapping, resampling and chunked overlap-add, inference tests, and output validation.
- The exact 1024×1024 house image provided in this conversation is installed as `Assets.xcassets/AppIcon.appiconset/AppIcon.png`.

## Open and build

1. On macOS, install a current Xcode version.
2. Open `TrapTube.xcodeproj`.
3. Select the `TrapTube` scheme and an iOS 17+ simulator.
4. Build and run. For a physical device, select your Apple development team in **Signing & Capabilities**.
5. To export an IPA, use Xcode’s Archive / Distribute workflow and select a signing/export method appropriate for the device. An IPA is not included because this environment has no Xcode, Apple SDK, or signing credentials.

The project has not been compiled or tested with Xcode in this environment. Treat Apple-platform compilation and runtime behavior as **unverified** until you build it on macOS.

## YouTube implementation notes

The parser accepts common watch, `youtu.be`, Shorts, live, embed and playlist URLs. A URL is transformed only into the official YouTube embed endpoint; no media URL resolution occurs. Playback requires the YouTube player’s own controls and remains subject to YouTube’s availability, branding, ads, privacy and playback rules. The WebView is configured to require user action before media playback.

## Stem model integration requirements

Before enabling local separation, add a properly licensed and validated Core ML package named `htdemucs.mlpackage` (Xcode compiles it into a `.mlmodelc` resource). Then implement a model-specific inference adapter that matches the exact tensor names, dimensions, sample rate, channel layout and normalization of the selected model. The current `StemSeparationService` intentionally reports availability only; it does not claim that a model can be run or that stems exist.

## App identity

The Xcode target currently retains the original bundle identifier `com.greatmusic.traptube` and display name `TrapTube`. Change those in target build settings / `Info.plist` before distribution if you are shipping under another name or bundle identifier.

## Build automation added

This handoff also includes:

- `scripts/build-unsigned-ipa.sh` — Xcode device build and unsigned IPA packaging script for macOS.
- `.github/workflows/build-ios-unsigned-ipa.yml` — hosted macOS GitHub Actions workflow that can compile the project and attach the unsigned IPA as a workflow artifact.
- `BUILD-STATUS.md` — validation evidence and exact signing/build limitations.

The current chat runtime is Linux-only. The project has passed syntax and plist checks, but an actual Xcode typecheck/build still must run on macOS. The generated IPA is unsigned so that a sideloading tool such as AltStore can sign it for a registered device; it is not an App Store distribution package.
