#!/usr/bin/env bash
set -euo pipefail

# Builds a device (iphoneos) app with Xcode on macOS, then packages it as an
# unsigned IPA. AltStore/AltServer can re-sign an unsigned IPA during sideloading.
# This does NOT create an App Store-signed or development-signed IPA.

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: This build requires macOS with Xcode and the iOS SDK." >&2
  echo "Run this script on a Mac, or use the included GitHub Actions workflow." >&2
  exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT="$PROJECT_ROOT/TrapTube.xcodeproj"
SCHEME="TrapTube"
CONFIGURATION="Release"
BUILD_ROOT="${BUILD_ROOT:-$PROJECT_ROOT/.ios-build}"
DERIVED_DATA="$BUILD_ROOT/DerivedData"
DIST_DIR="${DIST_DIR:-$PROJECT_ROOT/dist}"
LOG_FILE="$DIST_DIR/xcodebuild.log"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERROR: xcodebuild was not found. Install Xcode and select it with xcode-select." >&2
  exit 2
fi
if [[ ! -d "$PROJECT" ]]; then
  echo "ERROR: Xcode project not found: $PROJECT" >&2
  exit 2
fi

mkdir -p "$BUILD_ROOT" "$DIST_DIR"
rm -rf "$DERIVED_DATA"
mkdir -p "$DIST_DIR"

printf '\n== Xcode ==\n'
xcodebuild -version
printf '\n== Schemes ==\n'
xcodebuild -list -project "$PROJECT"

printf '\n== Building unsigned device app ==\n'
set +e
xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED_DATA" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  build 2>&1 | tee "$LOG_FILE"
BUILD_STATUS=${PIPESTATUS[0]}
set -e
if [[ "$BUILD_STATUS" -ne 0 ]]; then
  echo "ERROR: Xcode build failed. See $LOG_FILE" >&2
  exit "$BUILD_STATUS"
fi

APP_PATH="$DERIVED_DATA/Build/Products/${CONFIGURATION}-iphoneos/TrapTube.app"
if [[ ! -d "$APP_PATH" ]]; then
  echo "ERROR: Build reported success but app bundle is missing: $APP_PATH" >&2
  exit 3
fi

INFO_PLIST="$APP_PATH/Info.plist"
if [[ ! -f "$INFO_PLIST" ]]; then
  echo "ERROR: App bundle has no Info.plist." >&2
  exit 3
fi
EXECUTABLE=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$INFO_PLIST")
if [[ ! -f "$APP_PATH/$EXECUTABLE" ]]; then
  echo "ERROR: Compiled executable missing from app bundle: $EXECUTABLE" >&2
  exit 3
fi

IPA_PATH="$DIST_DIR/TrapTube-unsigned.ipa"
STAGING="$BUILD_ROOT/ipa-staging"
rm -rf "$STAGING"
mkdir -p "$STAGING/Payload"
ditto "$APP_PATH" "$STAGING/Payload/TrapTube.app"
rm -f "$IPA_PATH"
(
  cd "$STAGING"
  /usr/bin/zip -qry "$IPA_PATH" Payload
)

# Validate the archive structure and required bundle metadata.
/usr/bin/unzip -tq "$IPA_PATH"
/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$STAGING/Payload/TrapTube.app/Info.plist"
/usr/bin/shasum -a 256 "$IPA_PATH" > "$DIST_DIR/SHA256SUMS.txt"

printf '\nSUCCESS: Created unsigned IPA: %s\n' "$IPA_PATH"
printf 'This IPA is not signed. Use AltStore/AltServer to sign it for a device, or configure Apple signing in Xcode.\n'
