import SwiftUI

extension Color {
    init(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var value: UInt64 = 0
        Scanner(string: cleaned).scanHexInt64(&value)
        let red, green, blue: UInt64
        switch cleaned.count {
        case 3:
            red = ((value >> 8) & 0xF) * 17
            green = ((value >> 4) & 0xF) * 17
            blue = (value & 0xF) * 17
        case 6:
            red = (value >> 16) & 0xFF
            green = (value >> 8) & 0xFF
            blue = value & 0xFF
        default:
            red = 229; green = 9; blue = 32
        }
        self.init(.sRGB, red: Double(red) / 255, green: Double(green) / 255, blue: Double(blue) / 255, opacity: 1)
    }
}

struct TrapBackdrop: View {
    var body: some View {
        ZStack {
            Color.black
            RadialGradient(colors: [Color(hex: "39070D").opacity(0.46), .clear], center: .topTrailing, startRadius: 4, endRadius: 360)
            RadialGradient(colors: [Color(hex: "9F0017").opacity(0.25), .clear], center: .bottomLeading, startRadius: 8, endRadius: 270)
        }
        .ignoresSafeArea()
    }
}

struct BrandHeader: View {
    var title: String = "TRAPTUBE"
    var compact: Bool = false

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.system(size: compact ? 27 : 34, weight: .black, design: .rounded))
                    .italic()
                    .tracking(-1.3)
                    .foregroundStyle(.white)
                Capsule()
                    .fill(Color(hex: "E50920"))
                    .frame(width: compact ? 112 : 150, height: 4)
                    .rotationEffect(.degrees(-2))
                    .overlay(alignment: .bottomTrailing) {
                        Capsule().fill(Color(hex: "E50920").opacity(0.8)).frame(width: 3, height: 9).offset(x: -18, y: 6)
                    }
            }
            Spacer()
            CrownMark()
                .stroke(Color(hex: "E50920"), style: StrokeStyle(lineWidth: compact ? 4 : 5, lineCap: .round, lineJoin: .round))
                .frame(width: compact ? 52 : 68, height: compact ? 40 : 52)
                .shadow(color: Color(hex: "E50920").opacity(0.55), radius: 9)
                .accessibilityHidden(true)
        }
        .padding(.top, 4)
    }
}

struct CrownMark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width, h = rect.height
        path.move(to: CGPoint(x: w * 0.08, y: h * 0.22))
        path.addLine(to: CGPoint(x: w * 0.28, y: h * 0.54))
        path.addLine(to: CGPoint(x: w * 0.50, y: h * 0.08))
        path.addLine(to: CGPoint(x: w * 0.70, y: h * 0.52))
        path.addLine(to: CGPoint(x: w * 0.93, y: h * 0.20))
        path.addLine(to: CGPoint(x: w * 0.85, y: h * 0.76))
        path.addQuadCurve(to: CGPoint(x: w * 0.13, y: h * 0.78), control: CGPoint(x: w * 0.50, y: h * 0.68))
        path.move(to: CGPoint(x: w * 0.12, y: h * 0.91))
        path.addQuadCurve(to: CGPoint(x: w * 0.91, y: h * 0.88), control: CGPoint(x: w * 0.50, y: h * 0.95))
        return path
    }
}

struct CoverArt: View {
    var title: String
    var size: CGFloat = 58

    private var initials: String {
        let words = title.split(whereSeparator: \.isWhitespace)
        return String(words.prefix(2).compactMap(\.first)).uppercased()
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: "4A1117"), Color(hex: "181719"), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
            CrownMark().stroke(Color.white.opacity(0.62), style: StrokeStyle(lineWidth: max(2, size * 0.055), lineCap: .round, lineJoin: .round))
                .padding(size * 0.23)
            Text(initials)
                .font(.system(size: size * 0.17, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))
                .offset(y: size * 0.25)
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: size * 0.18).stroke(.white.opacity(0.08), lineWidth: 1))
        .accessibilityLabel("Artwork for \(title)")
    }
}

func formattedTime(_ time: TimeInterval) -> String {
    guard time.isFinite, time >= 0 else { return "0:00" }
    let total = Int(time)
    return "\(total / 60):\(String(format: "%02d", total % 60))"
}

func formattedBytes(_ bytes: Int64) -> String {
    ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
}
