import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    private enum Section: String, CaseIterable, Hashable { case songs = "Songs", playlists = "Playlists", recent = "Recent" }

    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager
    @State private var section: Section = .songs
    @State private var showImporter = false
    @State private var showCreatePlaylist = false
    @State private var playlistName = ""
    @State private var selectedPlaylist: LocalPlaylist?

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 17) {
                BrandHeader().padding(.horizontal, 20)
                Text("Library").font(.largeTitle.bold()).foregroundStyle(.white).padding(.horizontal, 18)

                HStack(spacing: 0) {
                    statBlock(label: "ON THIS DEVICE", value: "\(library.tracks.count) TRACKS", note: formattedBytes(library.totalStorageBytes) + " stored")
                    Rectangle().fill(.white.opacity(0.15)).frame(width: 1, height: 52)
                    statBlock(label: "PLAYLISTS", value: "\(library.playlists.count)", note: "Created locally")
                }
                .padding(14)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20))
                .padding(.horizontal, 16)

                Picker("Library section", selection: $section) {
                    ForEach(Section.allCases, id: \.self) { item in Text(item.rawValue).tag(item) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16)

                switch section {
                case .songs:
                    trackList(library.tracks, emptyTitle: "No local audio yet", emptyText: "Import audio files you own or have permission to use.")
                case .recent:
                    trackList(library.recentlyPlayed, emptyTitle: "Nothing played yet", emptyText: "Tracks played from this device will appear here.")
                case .playlists:
                    playlistSection
                }

                if section != .playlists {
                    Button { showImporter = true } label: {
                        Label("Import audio", systemImage: "plus")
                            .font(.headline.bold()).foregroundStyle(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 15)
                            .background(theme.accent, in: Capsule())
                    }
                    .padding(.horizontal, 16)
                }
            }
            .padding(.top, 7)
            .padding(.bottom, 20)
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { Task { await library.importAudio(from: urls) } }
            if case .failure(let error) = result { library.alertMessage = error.localizedDescription }
        }
        .alert("Create playlist", isPresented: $showCreatePlaylist) {
            TextField("Playlist name", text: $playlistName)
            Button("Cancel", role: .cancel) { playlistName = "" }
            Button("Create") { library.createPlaylist(named: playlistName); playlistName = "" }
        } message: { Text("Playlists are stored on this device.") }
        .sheet(item: $selectedPlaylist) { playlist in
            PlaylistDetailView(playlist: playlist).environmentObject(library).environmentObject(player).environmentObject(theme)
        }
    }

    private func statBlock(label: String, value: String, note: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.caption2.weight(.bold)).foregroundStyle(Color(hex: "A6A4A6"))
            Text(value).font(.system(size: 19, weight: .black)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.8)
            Text(note).font(.caption).foregroundStyle(Color(hex: "A6A4A6")).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 5)
    }

    private func trackList(_ tracks: [Track], emptyTitle: String, emptyText: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            if tracks.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text(emptyTitle).font(.headline).foregroundStyle(.white)
                    Text(emptyText).font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18)
                .background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 18))
            } else {
                ForEach(tracks) { track in
                    TrackRow(track: track, queue: tracks, subtitle: "\(formattedBytes(track.fileSizeBytes))  •  Added \(track.importedAt.formatted(date: .abbreviated, time: .omitted))")
                }
            }
        }
        .padding(.horizontal, 16)
    }

    private var playlistSection: some View {
        VStack(spacing: 10) {
            Button { showCreatePlaylist = true } label: {
                Label("Create playlist", systemImage: "plus.circle.fill")
                    .font(.headline).foregroundStyle(theme.accent)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
                    .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 16))
            }
            .buttonStyle(.plain)
            if library.playlists.isEmpty {
                Text("Your playlists stay on this device.")
                    .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 4)
            } else {
                ForEach(library.playlists) { playlist in
                    Button { selectedPlaylist = playlist } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "music.note.list").font(.title3.bold()).foregroundStyle(theme.accent)
                                .frame(width: 54, height: 54).background(theme.accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 14))
                            VStack(alignment: .leading, spacing: 4) {
                                Text(playlist.name).font(.headline).foregroundStyle(.white)
                                Text("\(playlist.trackIDs.count) tracks").font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(Color(hex: "777477"))
                        }
                        .padding(10)
                        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 17))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.horizontal, 16)
    }
}

private struct PlaylistDetailView: View {
    let playlist: LocalPlaylist
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager

    var body: some View {
        NavigationStack {
            ZStack { TrapBackdrop()
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("\(library.tracks(in: playlist).count) tracks").font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                        ForEach(library.tracks(in: playlist)) { track in
                            HStack {
                                TrackRow(track: track, queue: library.tracks(in: playlist))
                                Button { library.remove(track, from: playlist) } label: { Image(systemName: "minus.circle").foregroundStyle(Color(hex: "A6A4A6")) }
                                    .buttonStyle(.plain).accessibilityLabel("Remove from playlist")
                            }
                        }
                        if library.tracks(in: playlist).isEmpty {
                            Text("Add tracks from the Songs list using each track’s ••• menu.").font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                        }
                    }.padding(16)
                }
            }
            .navigationTitle(playlist.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() }.foregroundStyle(theme.accent) } }
        }
        .preferredColorScheme(.dark)
    }
}
