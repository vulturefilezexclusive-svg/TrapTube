import SwiftUI

struct EqualizerView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager

    private let labels = ["32", "64", "125", "250", "500", "1k", "2k", "3k", "4k", "5k", "6k", "7k", "8k", "10k", "12k", "16k"]

    var body: some View {
        ZStack {
            TrapBackdrop()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Capsule().fill(.white.opacity(0.3)).frame(width: 38, height: 5).frame(maxWidth: .infinity)
                        Button { dismiss() } label: { Image(systemName: "xmark").font(.headline.bold()).foregroundStyle(.white).frame(width: 38, height: 38).background(.white.opacity(0.1), in: Circle()) }
                            .accessibilityLabel("Close equalizer")
                    }
                    Text("Equalizer").font(.largeTitle.bold()).foregroundStyle(.white)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 6) {
                            ForEach(AudioEngineManager.presetNames, id: \.self) { preset in
                                GenrePill(title: preset, active: player.currentPreset == preset, tint: theme.accent) { player.applyPreset(preset) }
                            }
                        }.padding(.vertical, 2)
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(alignment: .top, spacing: 4) {
                            ForEach(0..<16, id: \.self) { index in
                                BandControl(label: labels[index], value: player.eqGains[index], tint: theme.accent) { player.setBand(index, gain: $0) }
                            }
                        }.padding(.horizontal, 2)
                    }
                    .padding(.vertical, 4)
                    VStack(spacing: 16) {
                        rangeControl(title: "Bass boost", value: Double(player.bassBoost), range: 0...20, suffix: "dB") { player.setBassBoost(Float($0)) }
                        rangeControl(title: "Volume", value: Double(player.masterGain * 100), range: 0...200, suffix: "%") { player.setMasterGain(Float($0 / 100)) }
                    }
                    .padding(16)
                    .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 20))
                    if player.clippingWarning {
                        Label("Clipping risk above 150% gain. Reduce master gain if you hear distortion.", systemImage: "exclamationmark.triangle.fill")
                            .font(.subheadline.bold()).foregroundStyle(Color(hex: "FF5362"))
                            .padding(14).frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(hex: "5A1019").opacity(0.8), in: RoundedRectangle(cornerRadius: 15))
                    }
                    Text("16 independent AVAudioEngine bands · adjustments apply immediately")
                        .font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                }
                .padding(20)
                .padding(.top, 14)
            }
        }
        .preferredColorScheme(.dark)
    }

    private func rangeControl(title: String, value: Double, range: ClosedRange<Double>, suffix: String, onChange: @escaping (Double) -> Void) -> some View {
        VStack(spacing: 8) {
            HStack { Text(title).font(.headline).foregroundStyle(.white); Spacer(); Text("\(Int(value))\(suffix)").font(.headline.monospacedDigit()).foregroundStyle(Color(hex: "C8C6C8")) }
            Slider(value: Binding(get: { value }, set: onChange), in: range).tint(theme.accent)
        }
    }
}

private struct BandControl: View {
    let label: String
    let value: Float
    let tint: Color
    let onChange: (Float) -> Void

    var body: some View {
        VStack(spacing: 6) {
            GeometryReader { geometry in
                let height = geometry.size.height
                let center = height / 2
                let clamped = min(max(CGFloat(value), -12), 12)
                let knobY = (12 - clamped) / 24 * height
                let top = min(center, knobY)
                let fillHeight = max(abs(center - knobY), 2)
                ZStack {
                    Capsule().fill(.white.opacity(0.15)).frame(width: 4)
                    Capsule().fill(tint).frame(width: 4, height: fillHeight).position(x: geometry.size.width / 2, y: top + fillHeight / 2)
                    Circle().fill(.white).frame(width: 15, height: 15).shadow(color: .black.opacity(0.3), radius: 3)
                        .position(x: geometry.size.width / 2, y: knobY)
                }
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { gesture in
                    let fraction = min(max(gesture.location.y / max(height, 1), 0), 1)
                    onChange(Float(12 - fraction * 24))
                })
                .accessibilityElement()
                .accessibilityLabel("\(label) hertz equalizer band")
                .accessibilityValue("\(Int(value)) decibels")
                .accessibilityAdjustableAction { direction in
                    switch direction {
                    case .increment: onChange(min(value + 1, 12))
                    case .decrement: onChange(max(value - 1, -12))
                    @unknown default: break
                    }
                }
            }
            .frame(width: 24, height: 150)
            Text(label).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white)
            Text("Hz").font(.system(size: 9)).foregroundStyle(Color(hex: "A6A4A6"))
        }
        .frame(width: 26)
    }
}
