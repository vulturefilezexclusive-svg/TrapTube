import SwiftUI

struct StemStudioView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var theme: ThemeManager
    @StateObject private var stemService = StemSeparationService()
    @State private var selectedTrackID: UUID?

    private var selectedTrack: Track? { library.tracks.first(where: { $0.id == selectedTrackID }) }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                BrandHeader().padding(.horizontal, 20)
                VStack(alignment: .leading, spacing: 7) {
                    Text("Stem Studio").font(.largeTitle.bold()).foregroundStyle(.white)
                    Text("Separate a local audio file into vocals, drums, bass and other instruments.")
                        .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                }.padding(.horizontal, 18)

                VStack(alignment: .leading, spacing: 13) {
                    Label("Local source", systemImage: "waveform").font(.headline.bold()).foregroundStyle(.white)
                    if library.tracks.isEmpty {
                        Text("Import an audio file in Home or Library to choose it here.")
                            .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                    } else {
                        Menu {
                            ForEach(library.tracks) { track in
                                Button(track.title) { selectedTrackID = track.id }
                            }
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(selectedTrack?.title ?? "Choose a library track")
                                        .font(.subheadline.bold()).foregroundStyle(.white).lineLimit(1)
                                    Text(selectedTrack == nil ? "No track selected" : "Stored on this device")
                                        .font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                                }
                                Spacer()
                                Image(systemName: "chevron.up.chevron.down").foregroundStyle(theme.accent)
                            }
                            .padding(13).background(.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 13))
                        }
                        .accessibilityLabel("Choose a local audio track")
                    }
                }
                .padding(16).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
                .padding(.horizontal, 16)

                VStack(alignment: .leading, spacing: 12) {
                    Label(stemService.availability.title, systemImage: "cpu")
                        .font(.headline.bold()).foregroundStyle(Color(hex: "FFB85C"))
                    Text(stemService.availability.detail)
                        .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                    Button {} label: {
                        Label("Separate into 4 stems", systemImage: "waveform.path")
                            .font(.headline.bold()).foregroundStyle(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 13)
                            .background(Color.gray.opacity(0.35), in: Capsule())
                    }
                    .disabled(true)
                    .accessibilityHint("Unavailable until a licensed Demucs Core ML model and tested inference adapter are added.")
                }
                .padding(16).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(hex: "FFB85C").opacity(0.18), lineWidth: 1))
                .padding(.horizontal, 16)

                VStack(alignment: .leading, spacing: 11) {
                    Text("Planned outputs").font(.headline.bold()).foregroundStyle(.white)
                    stemRow("Vocals", icon: "mic.fill")
                    stemRow("Drums", icon: "metronome.fill")
                    stemRow("Bass", icon: "waveform")
                    stemRow("Other", icon: "pianokeys")
                    Text("The mixer, solo/mute controls and WAV export become available only after genuine model inference produces validated stem files.")
                        .font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                        .padding(.top, 4)
                }
                .padding(16).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20))
                .padding(.horizontal, 16)

                Text("Only local files in your library are eligible. YouTube playback is never routed into stem processing.")
                    .font(.caption).foregroundStyle(Color(hex: "858185")).padding(.horizontal, 20)
            }
            .padding(.top, 8).padding(.bottom, 22)
        }
        .onAppear { stemService.refresh() }
        .onChange(of: library.tracks) { _, tracks in
            if !tracks.contains(where: { $0.id == selectedTrackID }) { selectedTrackID = tracks.first?.id }
        }
    }

    private func stemRow(_ name: String, icon: String) -> some View {
        HStack(spacing: 11) {
            Image(systemName: icon).foregroundStyle(theme.accent).frame(width: 24)
            Text(name).font(.subheadline.bold()).foregroundStyle(.white)
            Spacer()
            Text("Not generated").font(.caption).foregroundStyle(Color(hex: "858185"))
        }
        .padding(.vertical, 5)
    }
}
