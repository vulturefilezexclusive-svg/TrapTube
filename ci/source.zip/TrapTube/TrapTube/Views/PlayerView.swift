import SwiftUI

struct PlayerView: View {
    private enum Mode: String, CaseIterable, Hashable { case audio = "Audio", video = "Video" }

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var theme: ThemeManager
    @State private var mode: Mode = .audio
    @State private var showEqualizer = false
    @State private var scrubTime: Double = 0
    @State private var scrubbing = false

    var body: some View {
        ZStack {
            TrapBackdrop()
            if let track = player.currentTrack {
                VStack(spacing: 18) {
                    HStack {
                        Button { dismiss() } label: { Image(systemName: "chevron.down").font(.headline.bold()).foregroundStyle(.white).frame(width: 42, height: 42).background(.white.opacity(0.1), in: Circle()) }
                            .accessibilityLabel("Close player")
                        Spacer()
                        Text("NOW PLAYING").font(.caption.weight(.heavy)).tracking(1.7).foregroundStyle(Color(hex: "A6A4A6"))
                        Spacer()
                        Color.clear.frame(width: 42, height: 42).accessibilityHidden(true)
                    }
                    Picker("Playback mode", selection: $mode) {
                        ForEach(Mode.allCases, id: \.self) { item in Text(item.rawValue).tag(item) }
                    }
                    .pickerStyle(.segmented)
                    .tint(theme.accent)

                    if mode == .audio {
                        CoverArt(title: track.title, size: 270)
                            .frame(maxWidth: .infinity)
                            .shadow(color: theme.accent.opacity(0.18), radius: 24, y: 8)
                            .padding(.vertical, 4)
                    } else {
                        VStack(spacing: 12) {
                            Image(systemName: "video.slash").font(.system(size: 42)).foregroundStyle(theme.accent)
                            Text("No authorized video source connected").font(.headline).foregroundStyle(.white)
                            Text("Audio playback stays available. Video mode appears when a supported source is configured.")
                                .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6")).multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity, minHeight: 250)
                        .padding(20).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 24))
                    }

                    VStack(alignment: .leading, spacing: 5) {
                        Text(track.title).font(.title2.bold()).foregroundStyle(.white).lineLimit(1)
                        Text(track.artist).font(.headline).foregroundStyle(Color(hex: "A6A4A6")).lineLimit(1)
                    }.frame(maxWidth: .infinity, alignment: .leading)

                    VStack(spacing: 4) {
                        Slider(value: $scrubTime, in: 0...max(player.duration, 1), onEditingChanged: { editing in
                            scrubbing = editing
                            if !editing { player.seek(to: scrubTime) }
                        }).tint(theme.accent)
                        HStack {
                            Text(formattedTime(scrubTime)).foregroundStyle(Color(hex: "A6A4A6"))
                            Spacer()
                            Text(formattedTime(player.duration)).foregroundStyle(Color(hex: "A6A4A6"))
                        }.font(.caption.monospacedDigit())
                    }

                    HStack(spacing: 20) {
                        Button { player.isShuffled.toggle() } label: { Image(systemName: "shuffle").font(.title3).foregroundStyle(player.isShuffled ? theme.accent : .white) }.accessibilityLabel("Shuffle")
                        Button { player.previous() } label: { Image(systemName: "backward.end.fill").font(.title2).foregroundStyle(.white) }.accessibilityLabel("Previous track")
                        Button { player.togglePlayback() } label: {
                            Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 25, weight: .bold)).foregroundStyle(.white)
                                .frame(width: 70, height: 70).background(theme.accent, in: Circle()).shadow(color: theme.accent.opacity(0.4), radius: 15)
                        }.accessibilityLabel(player.isPlaying ? "Pause" : "Play")
                        Button { player.next() } label: { Image(systemName: "forward.end.fill").font(.title2).foregroundStyle(.white) }.accessibilityLabel("Next track")
                        Button { player.repeatsTrack.toggle() } label: { Image(systemName: player.repeatsTrack ? "repeat.1" : "repeat").font(.title3).foregroundStyle(player.repeatsTrack ? theme.accent : .white) }.accessibilityLabel("Repeat current track")
                    }
                    .frame(maxWidth: .infinity)

                    HStack(spacing: 12) {
                        controlBadge(icon: "slider.horizontal.3", title: "16-Band EQ") { showEqualizer = true }
                        controlBadge(icon: "waveform", title: "Bass +\(Int(player.bassBoost))dB") { showEqualizer = true }
                    }
                    Text("Local file · changes process on this device")
                        .font(.caption).foregroundStyle(Color(hex: "858185"))
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 22)
                .padding(.top, 12)
                .padding(.bottom, 18)
                .onAppear { scrubTime = player.currentTime }
                .onChange(of: player.currentTime) { _, newValue in if !scrubbing { scrubTime = newValue } }
                .onChange(of: player.currentTrack?.id) { _, _ in scrubTime = 0 }
            } else {
                ContentUnavailableView("Nothing playing", systemImage: "waveform", description: Text("Choose an imported track from your library."))
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showEqualizer) { EqualizerView().environmentObject(player).environmentObject(theme).presentationDetents([.large]) }
    }

    private func controlBadge(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon).font(.subheadline.bold()).foregroundStyle(.white)
                .frame(maxWidth: .infinity).padding(.vertical, 14)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
        }
    }
}
