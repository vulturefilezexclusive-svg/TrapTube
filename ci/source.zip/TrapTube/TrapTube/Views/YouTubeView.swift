import SwiftUI
import WebKit
import UIKit

struct YouTubeView: View {
    @EnvironmentObject private var theme: ThemeManager
    @State private var pastedURL = ""
    @State private var currentEmbed: YouTubeEmbedURL?
    @State private var errorMessage: String?

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                BrandHeader().padding(.horizontal, 20)
                VStack(alignment: .leading, spacing: 7) {
                    Text("YouTube").font(.largeTitle.bold()).foregroundStyle(.white)
                    Text("Play videos and playlists in YouTube’s official embedded player.")
                        .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6"))
                }.padding(.horizontal, 18)

                VStack(alignment: .leading, spacing: 12) {
                    TextField("Paste a YouTube video or playlist URL", text: $pastedURL, axis: .vertical)
                        .lineLimit(1...3)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .padding(13)
                        .background(.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 13))
                        .foregroundStyle(.white)
                        .accessibilityLabel("YouTube video or playlist URL")

                    Button(action: loadPlayer) {
                        Label("Load YouTube player", systemImage: "play.rectangle.fill")
                            .font(.headline.bold()).foregroundStyle(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 13)
                            .background(theme.accent, in: Capsule())
                    }
                    .buttonStyle(.plain)

                    if let errorMessage {
                        Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
                            .font(.footnote).foregroundStyle(Color(hex: "FF6472"))
                    }
                }
                .padding(16)
                .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.07), lineWidth: 1))
                .padding(.horizontal, 16)

                if let currentEmbed {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(currentEmbed.description).font(.headline.bold()).foregroundStyle(.white)
                            Spacer()
                            Button("Close") { self.currentEmbed = nil }
                                .font(.subheadline.bold()).foregroundStyle(theme.accent)
                        }
                        OfficialYouTubeWebView(embedURL: currentEmbed.url)
                            .frame(height: 235)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.1), lineWidth: 1))
                    }
                    .padding(16)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
                    .padding(.horizontal, 16)
                } else {
                    VStack(spacing: 12) {
                        Image(systemName: "play.rectangle.fill").font(.system(size: 38)).foregroundStyle(theme.accent)
                        Text("Ready when you are").font(.title3.bold()).foregroundStyle(.white)
                        Text("Paste a public YouTube link above. Tap the player’s own Play button to begin.")
                            .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6")).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity).padding(28)
                    .background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20))
                    .padding(.horizontal, 16)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Label("Playback stays inside YouTube", systemImage: "info.circle.fill")
                        .font(.subheadline.bold()).foregroundStyle(.white)
                    Text("This screen uses YouTube’s official embedded player. YouTube controls, branding, ads, availability rules and privacy practices apply. It does not download media, extract streams, remove ads, or send YouTube audio through TrapTube’s equalizer or stem processor. Playback stops when you close this screen.")
                        .font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                }
                .padding(16)
                .background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 16))
                .padding(.horizontal, 16)
            }
            .padding(.top, 8).padding(.bottom, 22)
        }
        .onDisappear { currentEmbed = nil }
    }

    private func loadPlayer() {
        guard let parsed = YouTubeEmbedURL.parse(pastedURL) else {
            errorMessage = "Enter a valid YouTube video or playlist URL."
            currentEmbed = nil
            return
        }
        errorMessage = nil
        currentEmbed = parsed
    }
}

private struct OfficialYouTubeWebView: UIViewRepresentable {
    let embedURL: URL

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = .all
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = UIColor.black
        webView.scrollView.backgroundColor = UIColor.black
        webView.scrollView.isScrollEnabled = false
        webView.navigationDelegate = context.coordinator
        webView.loadHTMLString(Self.html(for: embedURL), baseURL: URL(string: "https://www.youtube-nocookie.com"))
        context.coordinator.loadedURL = embedURL
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        guard context.coordinator.loadedURL != embedURL else { return }
        context.coordinator.loadedURL = embedURL
        webView.loadHTMLString(Self.html(for: embedURL), baseURL: URL(string: "https://www.youtube-nocookie.com"))
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        // The standard YouTube IFrame API accepts this stop command from its parent page.
        webView.evaluateJavaScript("document.querySelector('iframe')?.contentWindow?.postMessage(JSON.stringify({event:'command',func:'stopVideo',args:[]}), '*');")
        webView.stopLoading()
        webView.loadHTMLString("<!doctype html><html><body style='background:#000'></body></html>", baseURL: nil)
    }

    private static func html(for url: URL) -> String {
        let safeURL = url.absoluteString
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "\"", with: "&quot;")
        return """
        <!doctype html>
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <style>html,body{margin:0;padding:0;background:#000;width:100%;height:100%;overflow:hidden}iframe{border:0;width:100%;height:100%;min-width:200px;min-height:200px}</style>
        </head><body>
        <iframe id="player" src="\(safeURL)" title="YouTube video player" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </body></html>
        """
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        var loadedURL: URL?
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { }
    }
}
