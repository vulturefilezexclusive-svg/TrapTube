import SwiftUI
import UniformTypeIdentifiers

struct HomeView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager
    @State private var query = ""
    @State private var genre = "All"
    @State private var showImporter = false

    private let filters = ["All"] + LibraryStore.genreTags
    private var visibleTracks: [Track] {
        library.tracks.filter { track in
            let matchesGenre = genre == "All" || track.genre == genre
            let matchesQuery = query.isEmpty || track.title.localizedCaseInsensitiveContains(query) || track.artist.localizedCaseInsensitiveContains(query)
            return matchesGenre && matchesQuery
        }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                BrandHeader().padding(.horizontal, 20)
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass").foregroundStyle(Color(hex: "B6B3B5"))
                    TextField("Search your library", text: $query).textInputAutocapitalization(.never).autocorrectionDisabled().foregroundStyle(.white)
                }
                .padding(14)
                .background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().stroke(.white.opacity(0.1), lineWidth: 1))
                .padding(.horizontal, 16)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 9) {
                        ForEach(filters, id: \.self) { item in
                            GenrePill(title: item, active: genre == item, tint: theme.accent) { genre = item }
                        }
                    }
                    .padding(.horizontal, 16)
                }

                if library.tracks.isEmpty {
                    emptyState
                } else {
                    VStack(alignment: .leading, spacing: 6) {
                        SectionHeading(title: query.isEmpty ? (genre == "All" ? "Your rotation" : genre) : "Search results", trailing: "\(visibleTracks.count) tracks")
                        if visibleTracks.isEmpty {
                            Text("No tracks match this filter yet. Tag a local track from its ••• menu.")
                                .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6")).padding(.vertical, 22)
                        } else {
                            ForEach(visibleTracks) { track in TrackRow(track: track, queue: visibleTracks) }
                        }
                    }
                    .padding(.horizontal, 16)
                }

                if !library.recentlyPlayed.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        SectionHeading(title: "Recently played", trailing: "On this device")
                        ForEach(library.recentlyPlayed.prefix(4)) { track in TrackRow(track: track, queue: library.recentlyPlayed) }
                    }
                    .padding(.horizontal, 16)
                }
            }
            .padding(.top, 8)
            .padding(.bottom, 18)
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { Task { await library.importAudio(from: urls) } }
            if case .failure(let error) = result { library.alertMessage = error.localizedDescription }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "waveform").font(.system(size: 38, weight: .medium)).foregroundStyle(theme.accent)
            Text("Your sound. Your library.").font(.title3.bold()).foregroundStyle(.white)
            Text("Import audio files you own or have permission to use. They stay on this device.")
                .font(.subheadline).foregroundStyle(Color(hex: "A6A4A6")).multilineTextAlignment(.center)
            Button { showImporter = true } label: {
                Label("Import audio", systemImage: "plus")
                    .font(.headline.bold()).foregroundStyle(.white)
                    .padding(.horizontal, 22).padding(.vertical, 13)
                    .background(theme.accent, in: Capsule())
            }
            .padding(.top, 4)
        }
        .frame(maxWidth: .infinity).padding(28).padding(.top, 30)
        .background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 26))
        .padding(.horizontal, 16)
    }
}
