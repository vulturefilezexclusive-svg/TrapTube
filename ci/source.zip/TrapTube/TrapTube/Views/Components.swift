import SwiftUI

struct SectionHeading: View {
    let title: String
    var trailing: String? = nil
    var body: some View {
        HStack {
            Text(title).font(.title3.bold()).foregroundStyle(.white)
            Spacer()
            if let trailing { Text(trailing).font(.caption.weight(.semibold)).foregroundStyle(Color(hex: "A6A4A6")) }
        }
        .padding(.top, 8)
    }
}

struct GenrePill: View {
    let title: String
    let active: Bool
    let tint: Color
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(active ? .white : Color(hex: "D5D3D5"))
                .padding(.horizontal, 17)
                .padding(.vertical, 10)
                .background(active ? tint : Color.white.opacity(0.09), in: Capsule())
                .overlay(Capsule().stroke(.white.opacity(active ? 0 : 0.05), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct TrackRow: View {
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var theme: ThemeManager

    let track: Track
    let queue: [Track]
    var subtitle: String? = nil

    var body: some View {
        HStack(spacing: 12) {
            Button { player.play(track, from: queue); library.markPlayed(track) } label: {
                HStack(spacing: 12) {
                    CoverArt(title: track.title, size: 58)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(track.title).font(.system(size: 16, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                        Text(subtitle ?? track.artist).font(.subheadline).foregroundStyle(Color(hex: "A6A4A6")).lineLimit(1)
                        if let genre = track.genre { Text(genre.uppercased()).font(.system(size: 9, weight: .heavy)).tracking(1).foregroundStyle(theme.accent) }
                    }
                    Spacer(minLength: 4)
                    Text(formattedTime(track.duration)).font(.caption.monospacedDigit()).foregroundStyle(Color(hex: "A6A4A6"))
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            Menu {
                Menu("Set genre") {
                    ForEach(LibraryStore.genreTags, id: \.self) { genre in
                        Button(genre) { library.setGenre(genre, for: track) }
                    }
                    Button("Clear genre") { library.setGenre(nil, for: track) }
                }
                if !library.playlists.isEmpty {
                    Menu("Add to playlist") {
                        ForEach(library.playlists) { playlist in
                            Button(playlist.name) { library.add(track, to: playlist) }
                        }
                    }
                }
                Button(role: .destructive) { library.delete(track) } label: { Label("Remove from library", systemImage: "trash") }
            } label: {
                Image(systemName: "ellipsis").font(.body.bold()).foregroundStyle(.white).frame(width: 32, height: 44).contentShape(Rectangle())
            }
            .accessibilityLabel("Actions for \(track.title)")
        }
        .padding(.vertical, 7)
        .overlay(alignment: .bottom) { Rectangle().fill(.white.opacity(0.08)).frame(height: 1).padding(.leading, 70) }
    }
}

extension LibraryStore {
    static let genreTags = ["Trap", "Drill", "Phonk", "Late Night"]
}

struct MiniPlayer: View {
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager
    var open: () -> Void

    var body: some View {
        if let track = player.currentTrack {
            HStack(spacing: 11) {
                Button(action: open) { CoverArt(title: track.title, size: 48) }.buttonStyle(.plain)
                Button(action: open) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(track.title).font(.subheadline.bold()).foregroundStyle(.white).lineLimit(1)
                        Text(player.isPlaying ? "Playing from your library" : "Paused").font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }.buttonStyle(.plain)
                Button { player.togglePlayback() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.title3.bold()).foregroundStyle(.white).frame(width: 42, height: 44)
                }
                .accessibilityLabel(player.isPlaying ? "Pause" : "Play")
            }
            .padding(10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(alignment: .bottomLeading) {
                GeometryReader { geo in
                    Capsule().fill(theme.accent).frame(width: geo.size.width * (player.duration > 0 ? min(player.currentTime / player.duration, 1) : 0), height: 3)
                }.frame(height: 3).padding(.horizontal, 12).padding(.bottom, 1)
            }
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.08), lineWidth: 1))
        }
    }
}

struct BottomNavigation: View {
    @Binding var selection: RootView.Tab
    @EnvironmentObject private var theme: ThemeManager

    var body: some View {
        HStack(spacing: 0) {
            tab(.home, icon: "house.fill", title: "Home")
            tab(.library, icon: "books.vertical.fill", title: "Library")
            tab(.youtube, icon: "play.rectangle.fill", title: "YouTube")
            tab(.stems, icon: "waveform.path", title: "Stems")
            tab(.settings, icon: "gearshape.fill", title: "Settings")
        }
        .padding(.vertical, 9)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().stroke(.white.opacity(0.12), lineWidth: 1))
    }

    private func tab(_ tab: RootView.Tab, icon: String, title: String) -> some View {
        Button { selection = tab } label: {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 19, weight: .bold))
                Text(title).font(.caption2.weight(.bold))
            }
            .foregroundStyle(selection == tab ? theme.accent : Color(hex: "AAA8AA"))
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selection == tab ? .isSelected : [])
    }
}
