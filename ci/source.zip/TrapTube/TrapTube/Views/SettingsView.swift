import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager
    @AppStorage("typetype.baseAddress") private var typeTypeAddress = ""
    @State private var connectionStatus: String?
    @State private var checkingConnection = false
    @State private var showEqualizer = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                BrandHeader().padding(.horizontal, 20)
                Text("Settings").font(.largeTitle.bold()).foregroundStyle(.white).padding(.horizontal, 18)

                settingsCard(title: "Audio", icon: "slider.horizontal.3") {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("16-band equalizer").font(.headline).foregroundStyle(.white)
                            Text(player.currentPreset).font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                        }
                        Spacer()
                        Button("Adjust") { showEqualizer = true }.font(.subheadline.bold()).foregroundStyle(theme.accent)
                    }
                    Divider().overlay(.white.opacity(0.1))
                    gainSlider(title: "Bass boost", value: Double(player.bassBoost), range: 0...20, suffix: "dB") { player.setBassBoost(Float($0)) }
                    gainSlider(title: "Master gain", value: Double(player.masterGain * 100), range: 0...200, suffix: "%") { player.setMasterGain(Float($0 / 100)) }
                    if player.clippingWarning {
                        Label("Clipping risk above 150% gain. The dynamics stage is active.", systemImage: "exclamationmark.triangle.fill")
                            .font(.caption.weight(.semibold)).foregroundStyle(Color(hex: "FF5362"))
                            .padding(10).frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(hex: "5A1019").opacity(0.75), in: RoundedRectangle(cornerRadius: 12))
                    }
                    Text("Audio is processed locally through AVAudioEngine. High gain can still distort source audio.")
                        .font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                }

                settingsCard(title: "TypeType connection", icon: "server.rack") {
                    Text("Connect to an instance you control. This check only confirms the server is reachable; media features need compatible, authorized access.")
                        .font(.caption).foregroundStyle(Color(hex: "A6A4A6"))
                    TextField("https://your-instance.example", text: $typeTypeAddress)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                        .padding(12).background(.black.opacity(0.3), in: RoundedRectangle(cornerRadius: 12))
                        .foregroundStyle(.white)
                    HStack {
                        Button {
                            checkingConnection = true; connectionStatus = nil
                            Task {
                                defer { checkingConnection = false }
                                do { connectionStatus = try await TypeTypeService().checkHealth(baseAddress: typeTypeAddress) }
                                catch { connectionStatus = error.localizedDescription }
                            }
                        } label: {
                            Label(checkingConnection ? "Checking…" : "Check connection", systemImage: "network")
                                .font(.subheadline.bold()).foregroundStyle(.white).padding(.horizontal, 14).padding(.vertical, 10)
                                .background(theme.accent, in: Capsule())
                        }
                        .disabled(checkingConnection)
                        if let connectionStatus { Text(connectionStatus).font(.caption).foregroundStyle(connectionStatus.hasPrefix("Instance is") ? Color.green : Color(hex: "FF5362")).lineLimit(3) }
                    }
                }

                settingsCard(title: "Local library", icon: "externaldrive") {
                    infoRow("Audio quality", value: "Original imported file")
                    Divider().overlay(.white.opacity(0.1))
                    infoRow("Downloads", value: "Import files you’re allowed to use")
                    Divider().overlay(.white.opacity(0.1))
                    infoRow("Sponsor segments", value: "Unavailable until a permitted metadata source is configured")
                    Divider().overlay(.white.opacity(0.1))
                    infoRow("Stem separation", value: "Coming soon — no model installed")
                }

                settingsCard(title: "Theme colors", icon: "paintpalette") {
                    colorField("Accent", value: $theme.accentHex)
                    colorField("Background", value: $theme.backgroundHex)
                    colorField("Primary text", value: $theme.primaryTextHex)
                    colorField("Secondary text", value: $theme.secondaryTextHex)
                    HStack {
                        RoundedRectangle(cornerRadius: 8).fill(theme.accent).frame(width: 26, height: 26)
                        Text("Live preview").font(.subheadline.bold()).foregroundStyle(theme.primaryText)
                        Spacer()
                        Button("Reset") { theme.reset() }.font(.subheadline.bold()).foregroundStyle(theme.accent)
                    }.padding(.top, 4)
                }

                Text("TrapTube • Local-first audio player\nExternal media access is not enabled by default.")
                    .font(.caption).foregroundStyle(Color(hex: "858185")).multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity).padding(.vertical, 6)
            }
            .padding(.top, 7).padding(.bottom, 20)
        }
        .sheet(isPresented: $showEqualizer) { EqualizerView().environmentObject(player).environmentObject(theme).presentationDetents([.large]) }
    }

    private func settingsCard<Content: View>(title: String, icon: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Label(title, systemImage: icon).font(.headline.bold()).foregroundStyle(.white)
            content()
        }
        .padding(16)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.06), lineWidth: 1))
        .padding(.horizontal, 16)
    }

    private func gainSlider(title: String, value: Double, range: ClosedRange<Double>, suffix: String, onChange: @escaping (Double) -> Void) -> some View {
        VStack(spacing: 6) {
            HStack { Text(title).font(.subheadline.bold()).foregroundStyle(.white); Spacer(); Text("\(Int(value))\(suffix)").font(.subheadline.monospacedDigit()).foregroundStyle(Color(hex: "D2D0D2")) }
            Slider(value: Binding(get: { value }, set: onChange), in: range).tint(theme.accent)
        }
    }

    private func infoRow(_ title: String, value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).font(.subheadline.bold()).foregroundStyle(.white)
            Spacer(minLength: 10)
            Text(value).font(.caption).foregroundStyle(Color(hex: "A6A4A6")).multilineTextAlignment(.trailing).frame(maxWidth: 180, alignment: .trailing)
        }
    }

    private func colorField(_ label: String, value: Binding<String>) -> some View {
        let valid = theme.isValid(value.wrappedValue)
        return HStack {
            Text(label).font(.subheadline).foregroundStyle(.white).frame(width: 110, alignment: .leading)
            TextField("RRGGBB", text: value).textInputAutocapitalization(.characters).autocorrectionDisabled()
                .font(.system(.subheadline, design: .monospaced)).foregroundStyle(.white).padding(9)
                .background(.black.opacity(0.3), in: RoundedRectangle(cornerRadius: 9))
                .overlay(RoundedRectangle(cornerRadius: 9).stroke(valid ? .clear : Color.red, lineWidth: 1))
            Text(valid ? "✓" : "Invalid").font(.caption.bold()).foregroundStyle(valid ? Color.green : Color.red).frame(width: 48)
        }
    }
}
