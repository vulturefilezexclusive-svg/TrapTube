import SwiftUI
import Combine

struct RootView: View {
    enum Tab: Hashable { case home, library, youtube, stems, settings }

    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: AudioEngineManager
    @EnvironmentObject private var theme: ThemeManager
    @State private var selectedTab: Tab = .home
    @State private var showPlayer = false

    var body: some View {
        ZStack {
            ZStack {
                theme.background.ignoresSafeArea()
                RadialGradient(colors: [theme.accent.opacity(0.17), .clear], center: .topTrailing, startRadius: 4, endRadius: 330)
                RadialGradient(colors: [theme.accent.opacity(0.12), .clear], center: .bottomLeading, startRadius: 12, endRadius: 260)
            }.ignoresSafeArea()

            Group {
                switch selectedTab {
                case .home: HomeView()
                case .library: LibraryView()
                case .youtube: YouTubeView()
                case .stems: StemStudioView()
                case .settings: SettingsView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .safeAreaInset(edge: .bottom, spacing: 8) {
            VStack(spacing: 9) {
                MiniPlayer { showPlayer = true }
                    .environmentObject(player).environmentObject(theme)
                BottomNavigation(selection: $selectedTab).environmentObject(theme)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 4)
        }
        .preferredColorScheme(.dark)
        .tint(theme.accent)
        .fullScreenCover(isPresented: $showPlayer) {
            PlayerView().environmentObject(player).environmentObject(library).environmentObject(theme)
        }
        .onReceive(Timer.publish(every: 0.25, on: .main, in: .common).autoconnect()) { _ in player.refreshProgress() }
        .alert("TrapTube", isPresented: Binding(get: { library.alertMessage != nil || player.playbackError != nil }, set: { if !$0 { library.alertMessage = nil; player.clearPlaybackError() } })) {
            Button("OK") { library.alertMessage = nil; player.clearPlaybackError() }
        } message: {
            Text(library.alertMessage ?? player.playbackError ?? "")
        }
    }
}
