import SwiftUI

@main
struct TrapTubeApp: App {
    @StateObject private var library = LibraryStore()
    @StateObject private var audioEngine = AudioEngineManager()
    @StateObject private var theme = ThemeManager()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
                .environmentObject(audioEngine)
                .environmentObject(theme)
        }
    }
}
