import Foundation

struct Track: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var artist: String
    var fileName: String
    var duration: TimeInterval
    var fileSizeBytes: Int64
    var importedAt: Date = .now
    var genre: String?
}

struct LocalPlaylist: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var trackIDs: [UUID] = []
    var createdAt: Date = .now
}

struct LibrarySnapshot: Codable {
    var tracks: [Track] = []
    var playlists: [LocalPlaylist] = []
    var recentTrackIDs: [UUID] = []
}
