import Foundation

/// Minimal, opt-in health check for a user-controlled TypeType instance.
/// Media playback/search are intentionally not proxied through unsupported sources.
struct TypeTypeService {
    enum ServiceError: LocalizedError {
        case invalidAddress
        case badResponse(Int)

        var errorDescription: String? {
            switch self {
            case .invalidAddress: return "Enter a valid HTTPS address for your TypeType instance."
            case .badResponse(let code): return "The instance returned HTTP \(code)."
            }
        }
    }

    func checkHealth(baseAddress: String) async throws -> String {
        let trimmed = baseAddress.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard var components = URLComponents(string: trimmed), components.scheme == "https", components.host != nil else {
            throw ServiceError.invalidAddress
        }
        let prefix = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        components.path = prefix.isEmpty ? "/api/health" : "/\(prefix)/api/health"
        guard let url = components.url else { throw ServiceError.invalidAddress }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 10
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw ServiceError.badResponse(-1) }
        guard (200..<300).contains(http.statusCode) else { throw ServiceError.badResponse(http.statusCode) }
        return "Instance is reachable. Search and playback still require supported account access."
    }
}
