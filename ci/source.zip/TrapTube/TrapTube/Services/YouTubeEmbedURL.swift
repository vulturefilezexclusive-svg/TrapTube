import Foundation

/// Parses standard YouTube watch, short, shorts, live, embed, and playlist URLs.
/// It intentionally returns only an official embed URL; it never resolves stream URLs.
struct YouTubeEmbedURL: Equatable {
    let url: URL
    let description: String

    static func parse(_ rawValue: String) -> YouTubeEmbedURL? {
        let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              let candidate = URL(string: trimmed.contains("://") ? trimmed : "https://\(trimmed)"),
              let components = URLComponents(url: candidate, resolvingAgainstBaseURL: false),
              let host = components.host?.lowercased() else { return nil }

        let allowedHosts: Set<String> = [
            "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
            "youtu.be", "www.youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com"
        ]
        guard allowedHosts.contains(host) else { return nil }

        let pathParts = components.path.split(separator: "/").map(String.init)
        let query = components.queryItems ?? []
        let videoID: String? = {
            if host.contains("youtu.be") { return pathParts.first }
            if let value = query.first(where: { $0.name == "v" })?.value { return value }
            if pathParts.count >= 2, ["shorts", "live", "embed", "v"].contains(pathParts[0]) {
                return pathParts[1]
            }
            return nil
        }()
        let playlistID = query.first(where: { $0.name == "list" })?.value
        let validID = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")

        if let videoID,
           videoID.count >= 6,
           videoID.count <= 64,
           videoID.unicodeScalars.allSatisfy(validID.contains) {
            var embed = URLComponents(string: "https://www.youtube-nocookie.com/embed/\(videoID)")!
            embed.queryItems = [
                URLQueryItem(name: "playsinline", value: "1"),
                URLQueryItem(name: "enablejsapi", value: "1"),
                URLQueryItem(name: "rel", value: "0")
            ]
            if let playlistID, !playlistID.isEmpty { embed.queryItems?.append(URLQueryItem(name: "list", value: playlistID)) }
            guard let url = embed.url else { return nil }
            return YouTubeEmbedURL(url: url, description: "YouTube video")
        }

        if let playlistID,
           playlistID.count >= 5,
           playlistID.count <= 128,
           playlistID.unicodeScalars.allSatisfy(validID.contains) {
            var embed = URLComponents(string: "https://www.youtube-nocookie.com/embed/videoseries")!
            embed.queryItems = [
                URLQueryItem(name: "list", value: playlistID),
                URLQueryItem(name: "playsinline", value: "1"),
                URLQueryItem(name: "enablejsapi", value: "1"),
                URLQueryItem(name: "rel", value: "0")
            ]
            guard let url = embed.url else { return nil }
            return YouTubeEmbedURL(url: url, description: "YouTube playlist")
        }
        return nil
    }
}
