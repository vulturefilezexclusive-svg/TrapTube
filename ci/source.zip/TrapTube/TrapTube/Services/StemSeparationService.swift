import Foundation
import Combine

/// Honest availability boundary for the optional local Demucs/Core ML engine.
/// No bundled model exists in this source package, so separation remains disabled.
final class StemSeparationService: ObservableObject {
    enum Availability: Equatable {
        case missingModel
        case modelFoundButAdapterUnavailable

        var title: String {
            switch self {
            case .missingModel: return "Model not installed"
            case .modelFoundButAdapterUnavailable: return "Model found — runtime adapter needed"
            }
        }

        var detail: String {
            switch self {
            case .missingModel:
                return "No licensed htdemucs Core ML model is bundled. Add and validate a model package before enabling separation."
            case .modelFoundButAdapterUnavailable:
                return "A model resource exists, but its exact input/output tensor contract has not been validated. Separation stays disabled until the model adapter is implemented and tested."
            }
        }
    }

    @Published private(set) var availability: Availability = .missingModel

    init() { refresh() }

    func refresh() {
        let compiledModel = Bundle.main.url(forResource: "htdemucs", withExtension: "mlmodelc")
        let modelPackage = Bundle.main.url(forResource: "htdemucs", withExtension: "mlpackage")
        availability = (compiledModel != nil || modelPackage != nil)
            ? .modelFoundButAdapterUnavailable
            : .missingModel
    }
}
