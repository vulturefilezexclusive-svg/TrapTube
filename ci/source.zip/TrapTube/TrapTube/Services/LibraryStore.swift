import AVFoundation
import Foundation
import Combine

@MainActor
final class LibraryStore: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published private(set) var playlists: [LocalPlaylist] = []
    @Published private(set) var recentTrackIDs: [UUID] = []
    @Published var alertMessage: String?

    private let fileManager = FileManager.default
    private let metadataURL: URL

    static var appDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("TrapTube", isDirectory: true)
    }

    static var tracksDirectory: URL { appDirectory.appendingPathComponent("Tracks", isDirectory: true) }
    static func audioURL(for fileName: String) -> URL { tracksDirectory.appendingPathComponent(fileName) }

    init() {
        try? fileManager.createDirectory(at: Self.tracksDirectory, withIntermediateDirectories: true)
        metadataURL = Self.appDirectory.appendingPathComponent("library.json")
        load()
    }

    var totalStorageBytes: Int64 { tracks.reduce(0) { $0 + $1.fileSizeBytes } }
    var recentlyPlayed: [Track] { recentTrackIDs.compactMap { id in tracks.first(where: { $0.id == id }) } }

    func importAudio(from urls: [URL]) async {
        var messages: [String] = []
        for source in urls {
            let accessed = source.startAccessingSecurityScopedResource()
            defer { if accessed { source.stopAccessingSecurityScopedResource() } }
            do {
                let fileName = "\(UUID().uuidString).\(source.pathExtension.isEmpty ? "audio" : source.pathExtension)"
                let destination = Self.audioURL(for: fileName)
                try fileManager.copyItem(at: source, to: destination)
                let audioFile = try AVAudioFile(forReading: destination)
                let duration = Double(audioFile.length) / audioFile.processingFormat.sampleRate
                let size = (try fileManager.attributesOfItem(atPath: destination.path)[.size] as? NSNumber)?.int64Value ?? 0
                let title = source.deletingPathExtension().lastPathComponent
                tracks.insert(Track(title: title, artist: "Unknown artist", fileName: fileName, duration: duration, fileSizeBytes: size), at: 0)
            } catch {
                messages.append("\(source.lastPathComponent): \(error.localizedDescription)")
            }
        }
        persist()
        if !messages.isEmpty { alertMessage = messages.joined(separator: "\n") }
    }

    func markPlayed(_ track: Track) {
        recentTrackIDs.removeAll { $0 == track.id }
        recentTrackIDs.insert(track.id, at: 0)
        recentTrackIDs = Array(recentTrackIDs.prefix(30))
        persist()
    }

    func setGenre(_ genre: String?, for track: Track) {
        guard let index = tracks.firstIndex(where: { $0.id == track.id }) else { return }
        tracks[index].genre = genre
        persist()
    }

    func createPlaylist(named name: String) {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty else { return }
        playlists.insert(LocalPlaylist(name: cleanName), at: 0)
        persist()
    }

    func add(_ track: Track, to playlist: LocalPlaylist) {
        guard let index = playlists.firstIndex(where: { $0.id == playlist.id }), !playlists[index].trackIDs.contains(track.id) else { return }
        playlists[index].trackIDs.append(track.id)
        persist()
    }

    func remove(_ track: Track, from playlist: LocalPlaylist) {
        guard let index = playlists.firstIndex(where: { $0.id == playlist.id }) else { return }
        playlists[index].trackIDs.removeAll { $0 == track.id }
        persist()
    }

    func tracks(in playlist: LocalPlaylist) -> [Track] {
        playlist.trackIDs.compactMap { id in tracks.first(where: { $0.id == id }) }
    }

    func delete(_ track: Track) {
        try? fileManager.removeItem(at: Self.audioURL(for: track.fileName))
        tracks.removeAll { $0.id == track.id }
        recentTrackIDs.removeAll { $0 == track.id }
        for index in playlists.indices { playlists[index].trackIDs.removeAll { $0 == track.id } }
        persist()
    }

    private func load() {
        guard let data = try? Data(contentsOf: metadataURL), let snapshot = try? JSONDecoder().decode(LibrarySnapshot.self, from: data) else { return }
        tracks = snapshot.tracks.filter { fileManager.fileExists(atPath: Self.audioURL(for: $0.fileName).path) }
        playlists = snapshot.playlists
        recentTrackIDs = snapshot.recentTrackIDs
    }

    private func persist() {
        let snapshot = LibrarySnapshot(tracks: tracks, playlists: playlists, recentTrackIDs: recentTrackIDs)
        do {
            try fileManager.createDirectory(at: Self.appDirectory, withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(snapshot)
            try data.write(to: metadataURL, options: .atomic)
        } catch {
            alertMessage = "Could not save the music library: \(error.localizedDescription)"
        }
    }
}
