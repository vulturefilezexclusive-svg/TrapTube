import SwiftUI

@MainActor
final class ThemeManager: ObservableObject {
    @Published var accentHex: String { didSet { persist() } }
    @Published var backgroundHex: String { didSet { persist() } }
    @Published var primaryTextHex: String { didSet { persist() } }
    @Published var secondaryTextHex: String { didSet { persist() } }

    private let defaults = UserDefaults.standard
    private let defaultsMap = ["E50920", "080809", "FFFFFF", "A6A4A6"]

    init() {
        accentHex = defaults.string(forKey: "theme.accent") ?? "E50920"
        backgroundHex = defaults.string(forKey: "theme.background") ?? "080809"
        primaryTextHex = defaults.string(forKey: "theme.primaryText") ?? "FFFFFF"
        secondaryTextHex = defaults.string(forKey: "theme.secondaryText") ?? "A6A4A6"
    }

    var accent: Color { Color(hex: validated(accentHex, fallback: defaultsMap[0])) }
    var background: Color { Color(hex: validated(backgroundHex, fallback: defaultsMap[1])) }
    var primaryText: Color { Color(hex: validated(primaryTextHex, fallback: defaultsMap[2])) }
    var secondaryText: Color { Color(hex: validated(secondaryTextHex, fallback: defaultsMap[3])) }

    func reset() {
        accentHex = defaultsMap[0]
        backgroundHex = defaultsMap[1]
        primaryTextHex = defaultsMap[2]
        secondaryTextHex = defaultsMap[3]
    }

    func isValid(_ value: String) -> Bool {
        let raw = value.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        return (raw.count == 6 || raw.count == 3) && UInt64(raw, radix: 16) != nil
    }

    private func validated(_ value: String, fallback: String) -> String {
        isValid(value) ? value : fallback
    }

    private func persist() {
        defaults.set(accentHex, forKey: "theme.accent")
        defaults.set(backgroundHex, forKey: "theme.background")
        defaults.set(primaryTextHex, forKey: "theme.primaryText")
        defaults.set(secondaryTextHex, forKey: "theme.secondaryText")
    }
}
